<meta charset="UTF-8">
    <title><?=$title?></title>
    <link type = "text/css" rel = "stylesheet" href = "css/style.css">
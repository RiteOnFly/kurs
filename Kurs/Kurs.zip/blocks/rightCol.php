<div id="rightCol">
        <div class="banner"><img src="img/banner1.jpg" alt="banner" title="ban"></div>
        <div class="banner"><img src="img/banner2.jpg" alt="banner" title="ban"></div>
        <div class="banner"><img src="img/banner 3.jpg" alt="banner" title="ban"></div>
       <div class="banner"><img src="img/banner 4.jpg" alt="banner" title="ban"></div>
    </div>
    </div>
<header>

<div id="logo">
   <a href="/" title="Перейти на главную"> <img src="img/log.jpg" alt="logo" id="log"> <span>N</span>ews <img src="img/log.jpg" alt="logo" id="log"></a>
</div>
<div id="Headmenu">
 <a href="about.php"> <div style="margin-right:5%">  About us </div></a>
 <a href="feedback.php"><div> Feedback</div></a>
</div>
<a href="aut.php"><div id="AuthReg">
    Authorization</a> | <a href="reg.php">Registration</a>
</div>

</header>
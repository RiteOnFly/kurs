<footer>

<div id="social">

<a href="https://vk.com" title="Vk group" target="_blank"> <img src="img/vk.jpg" alt="vkontakte" title="Vk"></a>
<a href="https://facebook.com" title="fb group" target="_blank">  <img src="img/fb.jpg" alt="Facebook" title="Fb"></a>
<a href="https://www.instagram.com/" title="Inst blog" target="_blank">  <img src="img/inst.jpg" alt="Instagram" title="Inst"></a>
<a href="https://twitter.com" title="Twit blog" target="_blank">  <img src="img/Twit.jpg" alt="Twitter" title="Twit"></a>

</div>

<div id="rights">Все права защищенны &copy; <?=date('Y')?></div>

</footer>
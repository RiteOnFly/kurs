<!DOCTYPE html>
<html lang="en">
<head>

<?php
$title="Feedback";
 require_once "blocks/head.php";
 ?>
 <script src="js/script.js"></script>
   <script>"http://ajax.googleapis.com/ajax/libs/jquery/2.0.3/jquery.min.js"</script>
   <script>
   $(document).ready (function ()   {
        $("done").click (function ()    {
            var name = $("#name").val ();
            var email = $("#email").val ();
            var subject = $("#subject").val ();
            var message = $("#message").val ();
            var fail="";
            if(name.lenght < 2) fail = "Имя должно содержать не менее 2 символов";
            else if (email.split ('@').lenght - 1 ==0 || email.split ('.').lenght - 1 ==0)
                fail = "Неккоректный email";
            else if (subject.lengt <8)
                fail = "Тема сообщения менее 8 символов";
            else if (message.lengt <20)
                fail = "Сообщение содержит менее 20 символов";
            if (fail !="") {
                $('#messageShow').html (fail + "<div class='clear'><br></div>");
                $('#messageShow').show ();
                return false;
            }
        });

   });
   </script> 
</head>
<body>

<?php require_once "blocks/header.php" ?>
  
    <div id="wrapper">

        <div id="leftCol">
        <input type="text" placeholder="Name" id="name"><br />
        <input type="text" placeholder="Email" id="email"><br />
        <input type="text" placeholder="Subject" id="subject"><br />
        <textarea name="message" id="message" placeholder="Input your message"></textarea><br />
        <div id="messageShow"></div>
        <input type="button" name="Done" id="done" value="Send">
    </div>
    <?php require_once "blocks/rightCol.php" ?>
    </div>
    
    <?php require_once "blocks/footer.php" ?>
   
</body>
</html>